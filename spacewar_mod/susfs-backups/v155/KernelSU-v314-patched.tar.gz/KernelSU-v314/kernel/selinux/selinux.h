#ifndef __KSU_H_SELINUX
#define __KSU_H_SELINUX

#include "linux/types.h"
#include "linux/version.h"

void ksu_setup_selinux(const char *);

void ksu_setenforce(bool);

bool ksu_getenforce();

bool ksu_is_ksu_domain();

bool ksu_is_zygote(void *cred);

void ksu_apply_kernelsu_rules();

#ifdef CONFIG_KSU_SUSFS_SUS_MOUNT
bool susfs_is_sid_equal(void *sec, u32 sid2);
u32 susfs_get_sid_from_name(const char *secctx_name);
u32 susfs_get_current_sid(void);
void susfs_set_zygote_sid(void);
bool susfs_is_current_zygote_domain(void);
void susfs_set_ksu_sid(void);
bool susfs_is_current_ksu_domain(void);
void susfs_set_init_sid(void);
bool susfs_is_current_init_domain(void);
#endif

u32 ksu_get_devpts_sid();

#endif
