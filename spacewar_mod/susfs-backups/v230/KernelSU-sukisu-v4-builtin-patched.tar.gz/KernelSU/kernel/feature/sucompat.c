#define SU_PATH "/system/bin/su"
#define SH_PATH "/system/bin/sh"

bool ksu_su_compat_enabled __read_mostly = true;

static const char su_path[] = SU_PATH;
static const char sh_path[] = SH_PATH;
static const char ksud_path[] = KSUD_PATH;

static int su_compat_feature_get(u64 *value)
{
    *value = ksu_su_compat_enabled ? 1 : 0;
    return 0;
}

static int su_compat_feature_set(u64 value)
{
    bool enable = value != 0;
    ksu_su_compat_enabled = enable;
    pr_info("su_compat: set to %d\n", enable);
    return 0;
}

static const struct ksu_feature_handler su_compat_handler = {
    .feature_id = KSU_FEATURE_SU_COMPAT,
    .name = "su_compat",
    .get_handler = su_compat_feature_get,
    .set_handler = su_compat_feature_set,
};

static void __user *userspace_stack_buffer(const void *d, size_t len)
{
    // To avoid having to mmap a page in userspace, just write below the stack
    // pointer.
    char __user *p = (void __user *)current_user_stack_pointer() - len;

    return copy_to_user(p, d, len) ? NULL : p;
}

static char __user *sh_user_path(void)
{
    return userspace_stack_buffer(sh_path, sizeof(sh_path));
}

static char __user *ksud_user_path(void)
{
    return userspace_stack_buffer(ksud_path, sizeof(ksud_path));
}


#ifdef CONFIG_KSU_SUSFS
extern const char __user *get_user_arg_ptr(struct user_arg_ptr argv, int nr);
/*
 * return 0 -> No further checks should be required afterwards
 * return non-zero -> Further checks should be continued afterwards
 */
int ksu_handle_execveat_init(struct filename *filename, struct user_arg_ptr *argv_user, struct user_arg_ptr *envp_user) {
    int ret = 0;

    if (current->pid == 1)
        return -EINVAL;

    if (!is_init(get_current_cred()))
        return -EINVAL;

    if (unlikely(!strcmp(filename->name, KSUD_PATH))) {
        const char __user *argv_user_ptr = get_user_arg_ptr(*argv_user, 0);
        struct ksu_sulog_pending_event *pending_sucompat = NULL;

        pr_info("hook_manager: escape to root for init executing ksud: %d\n", current->pid);
        pending_sucompat = ksu_sulog_capture_sucompat(filename->name, argv_user, GFP_KERNEL);
        escape_to_root_for_init();
        if (ret) {
            pr_err("escape_to_root_for_init() failed: %d\n", ret);
            return ret;
        }
        if (!argv_user_ptr || IS_ERR(argv_user_ptr)) {
            pr_err("!argv_user_ptr || IS_ERR(argv_user_ptr)\n");
            return 0;
        }
        ksu_sulog_emit_pending(pending_sucompat, ret, GFP_KERNEL);
        return 0;
    }

    if (likely(!strstr(filename->name, "/app_process") && !strstr(filename->name, "/adbd") && !strstr(filename->name, "/stub_zygote"))) {
        pr_info("susfs: mark no sucompat checks for pid: '%d', exec: '%s'\n", current->pid, filename->name);
        susfs_set_current_proc_no_su();
        // - marking proc umounted here is useless because only zygote spawned processes will umount
        //   the sus mounts, tho other susfs features still rely on proc_umounted check, but
        //   it is fine to not spoof for init spawned processes.
        return 0;
    }

#ifdef CONFIG_KSU_FEATURE_ADBROOT
#ifdef CONFIG_COMPAT
    if (unlikely(envp_user->is_compat))
        ret = ksu_adb_root_handle_execveat(filename->name, (void ***)&envp_user->ptr.compat);
    else
        ret = ksu_adb_root_handle_execveat(filename->name, (void ***)&envp_user->ptr.native);
#else
        ret = ksu_adb_root_handle_execveat(filename->name, (void ***)&envp_user->ptr.native);
#endif
#endif

    if (ret)
        pr_err("adb root failed: %d\n", ret);

    return ret;
}

// the call from execve_handler_pre won't provided correct value for __never_use_argument, use them after fix execve_handler_pre, keeping them for consistence for manually patched code
int ksu_handle_execveat_sucompat(int *fd, struct filename **filename_ptr,
                 void *argv_user, void *envp_user,
                 int *__never_use_flags)
{
    struct filename *filename;
    struct ksu_sulog_pending_event *pending_sucompat = NULL;
    int ret;

    if (unlikely(!filename_ptr))
        return 0;

    filename = *filename_ptr;
    if (IS_ERR(filename))
        return 0;

    if (!ksu_handle_execveat_init(filename, (struct user_arg_ptr*)argv_user, (struct user_arg_ptr*)envp_user))
        return 0;

    if (!(__ksu_is_allow_uid_for_current(current_uid().val)))
        return 0;

    if (likely(memcmp(filename->name, su_path, sizeof(su_path))))
        return 0;

    if (current_chrooted())
    {
        pr_err("ksu_handle_execveat_sucompat: su found but NOT allowed! Because current process is running in chrooted environment\n");
        return 0;
    }

    pr_info("ksu_handle_execveat_sucompat: su found\n");

    memcpy((void *)filename->name, ksud_path, sizeof(ksud_path));

    pending_sucompat = ksu_sulog_capture_sucompat(filename->name, (struct user_arg_ptr*)argv_user, GFP_KERNEL);

    ret = escape_with_root_profile();
    if (ret)
        pr_err("escape_with_root_profile() failed: %d\n", ret);

    const char __user *argv_user_ptr = get_user_arg_ptr(*((struct user_arg_ptr*)argv_user), 0);
    if (!argv_user_ptr || IS_ERR(argv_user_ptr)) {
        pr_err("!argv_user_ptr || IS_ERR(argv_user_ptr)\n");
        return 0;
    }

    ksu_sulog_emit_pending(pending_sucompat, ret, GFP_KERNEL);
    return 0;
}

#ifdef KSU_COMPAT_USE_STATIC_KEY
extern struct static_key_true is_first_zygote;
#endif

int ksu_handle_execveat(int *fd, struct filename **filename_ptr, void *argv,
            void *envp, int *flags)
{
#ifdef KSU_COMPAT_USE_STATIC_KEY
    if (static_branch_unlikely(&is_first_zygote))
#else
    if (unlikely(first_zygote))
#endif
        (void)ksu_handle_execveat_ksud(fd, filename_ptr, argv, envp, flags);

    return ksu_handle_execveat_sucompat(fd, filename_ptr, argv, envp,
                        flags);
}

int ksu_handle_faccessat(int *dfd, struct filename **filename, int *mode,
             int *__unused_flags)
{
    if (unlikely(IS_ERR(*filename) || (*filename)->name == NULL))
        return 0;

    if (likely(memcmp((*filename)->name, su_path, sizeof(su_path))))
        return 0;

    if (current_chrooted())
    {
        pr_err("ksu_handle_faccessat: su found but NOT allowed! Because current process is running in chrooted environment\n");
        return 0;
    }
    pr_info("ksu_handle_faccessat: su->sh!\n");
    memcpy((void *)((*filename)->name), sh_path, sizeof(sh_path));
    return 0;
}

int ksu_handle_stat(int *dfd, struct filename **filename, int *flags) {
    if (unlikely(IS_ERR(*filename) || (*filename)->name == NULL))
        return 0;

    if (likely(memcmp((*filename)->name, su_path, sizeof(su_path))))
        return 0;

    if (current_chrooted())
    {
        pr_err("ksu_handle_stat: su found but NOT allowed! Because current process is running in chrooted environment\n");
        return 0;
    }
    pr_info("ksu_handle_stat: su->sh!\n");
    memcpy((void *)((*filename)->name), sh_path, sizeof(sh_path));
    return 0;
}

#else
__attribute__((hot)) static __always_inline bool __is_su_allowed(const void **ptr_to_check)
{
    if (!ksu_su_compat_enabled)
        return false;

    if (likely(test_thread_flag(TIF_SECCOMP)))
        return false;

    if (!ksu_is_allow_uid_for_current(current_uid().val))
        return false;

    if (unlikely(!ptr_to_check))
        return false;

    if (unlikely(!*ptr_to_check))
        return false;

    return true;
}
#define is_su_allowed(ptr) (__is_su_allowed((const void **)ptr))

static noinline int ksu_sucompat_user_common(const char __user **filename_user, const char *syscall_name,
                                             const bool escalate)
{
    char path[sizeof(su_path)] = { 0 }; // sizeof includes nullterm already!
    long len = ksu_strncpy_from_user_nofault(path, *filename_user, sizeof(path));
    int ret = 0;

    if (unlikely(len <= 0))
        return -EFAULT;

    if (likely(memcmp(path, su_path, sizeof(su_path))))
        return 0;

    if (!escalate)
        goto no_escalate;

    ret = escape_with_root_profile();
    if (!!ret)
        return ret;

    // NOTE: we only check file existence, not exec success!
    struct path kpath;
    if (!!kern_path(ksud_path, 0, &kpath))
        goto no_ksud;

    path_put(&kpath);
    pr_info("%s su->ksud!\n", syscall_name);
    *filename_user = ksud_user_path();
    return 0;

no_ksud:
no_escalate:
    pr_info("%s su->sh!\n", syscall_name);
    *filename_user = sh_user_path();
    return 0;
}

int ksu_handle_faccessat(int *dfd, const char __user **filename_user, int *mode, int *__unused_flags)
{
    if (!is_su_allowed(filename_user))
        return 0;

    ksu_sucompat_user_common(filename_user, "faccessat", false);
    return 0;
}

int ksu_handle_stat(int *dfd, const char __user **filename_user, int *flags)
{
    if (!is_su_allowed(filename_user))
        return 0;

    ksu_sucompat_user_common(filename_user, "newfstatat", false);
    return 0;
}

int ksu_handle_execve_sucompat(int *fd, const char __user **filename_user, void *argv, void *__never_use_envp,
                               int *__never_use_flags)
{
    struct ksu_sulog_pending_event *pending_root_execve = NULL;
    int ret = 0;

    if (!is_su_allowed(filename_user))
        return 0;

    pending_root_execve =
        ksu_sulog_capture_sucompat(*filename_user, *((struct user_arg_ptr *)argv), GFP_KERNEL);

    ret = ksu_sucompat_user_common(filename_user, "sys_execve", true);
    ksu_sulog_emit_pending(pending_root_execve, ret, GFP_KERNEL);
    return 0;
}

int ksu_handle_execveat_sucompat(int *fd, struct filename **filename_ptr, void *argv, void *__never_use_envp,
                                 int *__never_use_flags)
{
    struct ksu_sulog_pending_event *pending_root_execve = NULL;
    int ret = 0;

    if (!is_su_allowed(filename_ptr))
        return 0;

    if (likely(memcmp((void *)(*filename_ptr)->name, su_path, sizeof(su_path))))
        return 0;

    pending_root_execve =
        ksu_sulog_capture_sucompat((*filename_ptr)->name, *((struct user_arg_ptr *)argv), GFP_KERNEL);

    ret = escape_with_root_profile();
    ksu_sulog_emit_pending(pending_root_execve, ret, GFP_KERNEL);
    if (!!ret)
        return 0;

    // NOTE: we only check file existence, not exec success!
    struct path kpath;
    if (!!kern_path("/data/adb/ksud", 0, &kpath))
        goto no_ksud;

    path_put(&kpath);
    pr_info("do_execveat_common su->ksud!\n");
    memcpy((void *)(*filename_ptr)->name, ksud_path, sizeof(ksud_path));
    return 0;

no_ksud:
    pr_info("do_execveat_common su->sh!\n");
    memcpy((void *)(*filename_ptr)->name, sh_path, sizeof(sh_path));
    return 0;
}

extern bool ksu_execveat_hook __read_mostly;
int ksu_handle_execveat(int *fd, struct filename **filename_ptr, void *argv, void *envp, int *flags)
{
#ifdef CONFIG_KSU_FEATURE_ADBROOT
    int ret = 0;
    if (current_uid().val != 1 && is_init(get_current_cred())) {
        ret = ksu_adb_root_handle_execve_manual((*filename_ptr)->name, (struct user_arg_ptr *)envp);
        if (ret) {
            pr_err("adb root failed: %d\n", (int)ret);
        }
    }
#endif

    if (unlikely(ksu_execveat_hook)) {
        return ksu_handle_execveat_ksud(fd, filename_ptr, argv, envp, flags);
    }

    return ksu_handle_execveat_sucompat(fd, filename_ptr, argv, envp, flags);
}

// dead code
int __maybe_unused ksu_handle_devpts(struct inode *inode)
{
    return 0;
}
#endif

// sucompat: permitted process can execute 'su' to gain root access.
void __init ksu_sucompat_init(void)
{
    if (ksu_register_feature_handler(&su_compat_handler)) {
        pr_err("Failed to register su_compat feature handler\n");
    }
}

void __exit ksu_sucompat_exit(void)
{
    ksu_unregister_feature_handler(KSU_FEATURE_SU_COMPAT);
}
